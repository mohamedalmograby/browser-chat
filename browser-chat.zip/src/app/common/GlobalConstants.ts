export class GlobalConstants {
    public static currentUserId: string = "";
}