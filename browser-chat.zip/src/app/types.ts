export interface Message{
from:string;
to:string;
content:string;
time:string
}
export interface LocalStorageMessage{
content:string;
time:string
}
export interface User{
id:string;
name:string;
img_src:string;
status:string;
}
  